Copied from /data/data/void.gallery while the app was still running.
Visible SQLite rows are not enough. Do not trust obvious flag-like deleted notes without using the image cache.
