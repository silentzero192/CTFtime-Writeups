Old notes were cleaned up before release. Check what changed.
